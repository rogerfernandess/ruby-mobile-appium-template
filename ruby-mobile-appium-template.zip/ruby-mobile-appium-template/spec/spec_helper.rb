require 'rubygems'
require 'rspec'
require 'rspec/autorun'
